# lambda_dogdoor
